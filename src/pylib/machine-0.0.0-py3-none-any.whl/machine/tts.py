from _customtype import uint8

class TTS:
  """ 语音合成模块(I2C) """
  def __init__(self) -> None:
    """ 语音合成实例 """
    pass

  def setMode (self, fgVol: uint8, bgVol: uint8, speed: uint8):
    """ 
    设置音量及语速 
    
    *@param* `fgVol` - 前景音量: 0-16;

    *@param* `bgVol` - 后景音量: 0-16;

    *@param* `speed` - 语速: 0-5

    e.g.

    TTS().setMode(10, 0, 3)
    """
    pass

  def playTextH (self, ctx: str, bgm: uint8):
    """ 
    所有语音合成播放自定义内容

    *@param* `ctx` - 内容: 必须为GBK十六进制编码, 汉字转GBK可参照 https://www.toolhelper.cn/EncodeDecode/EncodeDecode; 数字转GBK可使用内置代码片段float2gbk;

    *@param* `bgm` - 背景乐: 0-15

    e.g.

    TTS().playTextH("C4E3BAC3", 0) # 播放你好

    TTS().playTextH(float2gbk(-1.1)) # 需先定义float2gbk
    """
    pass 

  def playTextI (self, id: uint8, ctx: str, bgm: uint8):
    """
    指定编号语音合成播放自定义内容

    *@param* `id` - 编号: 1/2;

    *@param* `ctx` - 内容: 必须为GBK十六进制编码, 汉字转GBK可参照 https://www.toolhelper.cn/EncodeDecode/EncodeDecode; 数字转GBK可使用内置代码片段float2gbk;

    *@param* `bgm` - 背景乐: 0-15

    e.g.

    TTS().playTextI(1, "C4E3BAC3", 0) # 1号语音合成播放你好

    TTS().playTextI(2, float2gbk(-1.1)) # 2号语音合成播放-1.1, 需先定义float2gbk
    """
    pass

  def playBeepH (self, hint: uint8):
    """  
    所有语音合成播放提示音

    *@param* `hint` - 提示音: 1-48(内置音频编号)
    
    """
    pass

  def playBeepI (self, id: uint8, hint: uint8):
    """  
    指定语音合成播放提示音

    *@param* `id` - 编号: 1/2;

    *@param* `hint` - 提示音: 1-48(内置音频编号)
    """
    pass
  