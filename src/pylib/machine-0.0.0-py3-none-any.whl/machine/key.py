from _customtype import bit

class Key:
  """ 板载按键 """

  def __init__(self) -> None:
    """
    板载按键实例
    """
    pass
  
  def readA(self) -> bit:
    """ 
    读取按键A状态\n

    *@returns* - 0(按下)/1(松开); 注：同外接按钮返回值相反

    e.g.

    Key().readA()
    """
    return 1
  
  def readB(self) -> bit:
    """ 
    读取按键B状态\n

    *@returns* - 0(按下)/1(松开); 注：同外接按钮返回值相反

    e.g.

    Key().readB()
    """
    return 1

