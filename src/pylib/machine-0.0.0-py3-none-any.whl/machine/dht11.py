from pyb._customtype import IoPort, uint8

class DHT11:
  """ DHT11温湿度传感器 """

  def __init__(self, port: IoPort) -> None:
    """ 
    DHT11实例

    *@param* `port` - 接口编号: 1、2、5、8、11、12、13、14、15、19、20
    """
    pass

  def readTem(self) -> uint8:
    """ 
    读取温度值

    *@returns* - 单位摄氏度℃

    e.g.\n
    DHT11(1).readTem()  
    """
    return 0
  
  def readHum(self) -> uint8:
    """ 
    读取湿度值

    *@returns* - 单位%

    e.g.\n
    DHT11(1).readHum()  
    """
    return 0