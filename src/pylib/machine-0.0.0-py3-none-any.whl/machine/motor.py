from _customtype import bit, uint8

class Motor:
  """ 电机 """
  def __init__(self, group: uint8) -> None:
    """ 
    电机实例 
    
    *@param* `group` - 电机组: 1/2
    """
    pass

  def start (self, mode: bit, speed: uint8) -> None:
    """ 
    电机启动

    *@param* `mode` - 模式: 0(正转)/1(反转)

    *@param* `speed` - 速度: 0-100

    e.g.

    Motor(1).start(0, 50)
    """
    pass