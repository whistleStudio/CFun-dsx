from _customtype import uint8

# 需连接在主控P1-6接口
class RFID:
  """ 射频IC传感器(IIC) """

  def __init__(self) -> None:
    """ 射频IC实例 """
    pass

  def readCode(self) -> uint8:
    """ 
    读取IC卡编号

    *@returns* - 编号可由IC卡上丝印得知  

    e.g.
    
    RFID().readCode()
    """
    return 0


