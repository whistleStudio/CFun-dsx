from machine._customtype import uint16
from typing import Literal



class MQTT:
  """ 
  板载物联网模块 

  需结合物联网平台iot.cfunworld.com使用
 
  e.g.\n
  ```python
  from machine import MQTT
  from time import sleep
  mqtt = MQTT()
  mqtt.connectWiFi("wifiname", "password1") # 修改wifi名称及密码
  while not mqtt.checkWiFi() :
    pass
  mqtt.setMqtt("username", "1", "password2") # 修改用户名、设备ID及连接密钥
  mqtt.connectTCP("iot.cfunworld.com", "1883") 
  while not mqtt.checkMqtt() :
    pass
  mqtt.subscribe("1", "CmsgW")
  sleep(1)
  while True:
    if mqtt.readData("1", "CmsgW"):
      print(mqtt.mqtt_string)
    mqtt.publishStr("Cmsg", "hello cfunworld")
    sleep(2)
  ```
  """

  mqtt_string: str
  mqtt_dataA: float
  mqtt_dataB: float
  mqtt_dataC: float
  mqtt_dataD: float

  def __init__(self) -> None:
    """
    板载物联网实例
    """
    pass

  def connectWiFi(self, wifi: str, password: str) -> None:
    """ 
    初始化步骤1: 连接无线网; 连接过程需消耗一定时间, 建议调用后等待>9秒

    *@param* `wifi` - 无线网名称(英文字符和数字构成, 且不包含空格);
    *@param* `password` - 无线网密码
    """
    pass
  
  def checkWiFi(self) -> bool:
    """ 
    初始化步骤2: 校验无线网连接状态

    *@returns* - 连接是否成功, True时, 可进行后续物联网操作
    """
    return False
  
  def setMqtt(self, username: str, deviceId: str, password: str) -> None:
    """  
    初始化步骤3: 设置物联网登录信息, 由物联网平台iot.cfunworld.com生成
    
    *@param* `username` - 用户名;\n
    *@param* `deviceId` - 设备ID;\n
    *@param* `password` - 连接密钥
    """
    pass

  def connectTCP(self, ip: str, port: str) -> None:
    """ 
    初始化步骤4: 连接物联网; 连接过程需消耗一定时间, 建议调用后等待>1秒

    *@param* `ip` - 服务ip: "iot.cfunworld.com";\n
    *@param* `port` - 端口号: "1883"
    """
    pass

  def checkMqtt(self) -> bool:
    """ 
    初始化步骤5: 校验物联服务连接状态

    *@returns* - 连接是否成功, True时, 可进行后续物联网操作
    """
    return False
  
  def cleanMqtt(self) -> None:
    """ 
    主动断开物联网连接
    """
    pass

  def publishNum(self, topic: str, dataA: float, dataB: float, dataC: float, dataD: float) -> None:
    """ 
    向创建连接设备的指定主题发布数值信息; 发布行为间隔>=1秒

    *@param* `topic` - 发布主题的名称: 主题"Cnum1"对应平台数据监控的数据A-D, 主题"Cnum2"对应平台数据监控的数据E-H;\n
    *@param* `dataA` - 数据A;\n
    *@param* `dataB` - 数据B;\n
    *@param* `dataC` - 数据C;\n
    *@param* `dataD` - 数据D
    """
    pass

  def publishStr(self, topic: str, data: str) -> None:
    """ 
    向创建连接设备的指定主题发布字符串信息

    *@param* `topic` - 发布主题的名称: 主题"Cmsg"对应平台会话监听;\n
    *@param* `data` - 文本信息
    """
    pass

  def subscribe(self, deviceId: str, topic: str) -> None:
    """ 
    订阅指定设备的指定主题; 订阅行为间隔>=1秒

    *@param* `deviceId` - 设备ID;\n
    *@param* `topic` - 订阅主题的名称: 主题"CmsgW"监控平台控制界面的发布会话; 主题"Cbtn"监控平台控制界面的按钮A-D, 主题"Cran"监控平台控制界面的滑杆A-D
    """
    pass

  def unsubscribe(self, deviceId: str, topic: str) -> None:
    """
    取消订阅指定设备的指定主题

    *@param* `deviceId` - 设备ID;\n
    *@param* `topic` - 取消订阅主题的名称: 主题"CmsgW"监控平台控制界面的发布会话, 主题"Cbtn"监控平台控制界面的按钮A-D, 主题"Cran"监控平台控制界面的滑杆A-D
    """
    pass

  def readData(self, deviceId: str, topic: str) -> bool:
    """
    校验是信息接收状态
    
    同时刷新数据mqtt_string、mqtt_dataA/B/C/D缓存
    
    *@returns* - 是否接收到信息
    """
    return False
  

