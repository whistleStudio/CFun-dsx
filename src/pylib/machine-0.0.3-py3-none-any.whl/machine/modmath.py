class Modmath:
  """ 数学运算 """
  def __init__(self) -> None:
    pass

  def randomint (self, a: int, b: int) -> int:
    """ a-b之间随机取整, 左闭右闭 """
    return 0
  
  def round (self, a: float) -> int:
    """ 四舍五入取整 """
    return 0
  
  def pow (self, a: float, b: float) -> float:
    """ a的b次方 """
    return 0

  def sqrt (self, a: float) -> float:
    """ a的平方根 """
    return 0

  def sin (self, angle: float) -> float:
    return 0.0
  
  def cos (self, angle: float) -> float:
    return 0.0
  
  def tan (self, angle: float) -> float:
    return 0.0
  
  def asin (self, angle: float) -> float:
    return 0.0
  
  def acos (self, angle: float) -> float:
    return 0.0
  
  def atan (self, angle: float) -> float:
    return 0.0
  
