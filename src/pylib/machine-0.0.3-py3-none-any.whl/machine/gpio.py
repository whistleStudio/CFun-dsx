from machine._customtype import bit, uint8, short, IoPort, IoPortMode, ADCPort

class Pin:
  """ 基本数字输入/输出 """
  def __init__(self, port: IoPort, mode: IoPortMode) -> None:
    """ 
    引脚实例: 基本数字输入/输出

    *@param* `port` - 接口编号: 1、2、5、8、11、12、13、14、15、19、20;

    *@param* `mode` - 模式: "in"(输入)、"out"(输出)
    """
    pass

  def digitalWrite(self, val: bit) -> None:
    """
    设置数字接口输出电平

    *@param* `val` - 0(低)/1(高);

    e.g.

    Pin(1,"out").digitalWrite(1)
    
    """
    pass
  
  def digitalRead(self) -> bit:
    """
    读取数字接口电平

    *@returns* - 0(低)/1(高)
    
    e.g.

    Pin("A0",Pin.IN).value()
    """
    return False


class PWM:
  """ 脉宽调制输出(类模拟输出) """
  def __init__(self, port: IoPort) -> None:
    """ 
    引脚实例: 脉宽调制输出(类模拟输出)

    *@param* `port` - 接口编号: 1、2、5、8、11、12、13、14、15、19、20;
    """
    pass

  def out(self, val: uint8, freq: int) -> None:
    """ 
    设置PWM输出

    *@param* `out` - 占空比: 取值0-100;

    *@param* `freq` - 频率

    e.g.

    PWM(1).out(50, 10000)
    """
    pass


class ADC:
  """ 模拟输入 """
  def __init__(self, port: ADCPort) -> None:
    """
    引脚实例: 模拟输入

    *@param* `port` - 接口编号: 1、2、13、14、20;
    """
    pass

  def read(self) -> short:
    """
    读取模拟接口量
    
    *@returns* - 0-1023

    e.g.

    ADC(1).read() 
    """
    return 0
  
