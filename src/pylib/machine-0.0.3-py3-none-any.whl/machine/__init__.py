"""
🤖创趣machine接口文档

https://dict.cfunworld.com/apidoc/cfdsx/
"""

from .gpio import Pin, PWM, ADC
from .key import Key
from .asr import ASR
from .dht11 import DHT11
from .moisture import Moisture
from .weigh import Weigh
from .rfid import RFID
from .oled import OLED
from .motor import Motor
from .servo import Servo
from .buzzer import Buzzer
from .tts import TTS
from .aivision import AIVision
from .mqtt import MQTT
from .modmath import Modmath
from ._customtype import *