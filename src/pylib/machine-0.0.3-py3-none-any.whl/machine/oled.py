from typing import Literal, Annotated
from dataclasses import dataclass
from deprecated import deprecated

@dataclass
class ValueRange:
  min: int
  max: int

Y = Annotated[int, ValueRange(1, 64)]
X = Annotated[int, ValueRange(1, 128)]

Size = Literal["big", "small"]
DisplayMode = Literal["forward", "reverse"]

class OLED: 
  """ 板载128*64显示屏 """
  
  def __init__(self) -> None:
    """ 板载屏实例 """
    pass

  def displayChinese(self, x: X, y: Y, mode: DisplayMode, text: str) -> None:
    """
    显示字符; 屏幕左上角为坐标原点, 以左X正半轴, 以下Y正半轴; 单个字符16x16像素

    *@param* `x` - 横坐标(单位:像素点): 0-127;

    *@param* `y` - 纵坐标(单位:像素点): 0-63;

    *@param* `mode` - 显示模式: "forward"(黑底蓝字)/"reverse"(蓝底黑字); 
    
    *@param* `text` - 文本

    e.g.

    oled = OLED()\n
    oled.clear()\n
    oled.displayChinese(1, 1, "forward", "你好123Abc!")\n
    oled.enableDisplay()
    """
    pass 

  def enableDisplay(self) -> None:
    """ 显示生效 """
    pass

  def clear(self) -> None:
    """
    清屏(留黑底)
    """
    pass

  @deprecated(reason="新版本固件可能不支持, 建议使用displayChinese", category=Warning)
  def displayStr(self, x: X, y: Y, size: Size, mode: DisplayMode, val: str) -> None: 
    """
    仅可显示英文字符或数字

    *@param* `x` - 横坐标(单位:像素点): 0-127;
    
    *@param* `y` - 纵坐标(单位:像素点): 0-63;
    
    *@param* `size` - 字号: "big"(大16x16)/"small"(小8x8)
    
    *@param* `mode` - 显示模式: "forward"(黑底蓝字)/"reverse"(蓝底黑字); 
    
    *@param* `val` - 英文数字字符文本

    e.g.

    OLED().displayStr(1, 1, "big", "forward", "hello1") 
    """
    pass

  @deprecated(reason="新版本固件可能不支持, 建议使用displayChinese", category=Warning)
  def displayNum(self, x: X, y: Y, size: Size, mode: DisplayMode, num: float) -> None:
    """
    仅可显示数字

    *@param* `x` - 行号(单位:像素点): 1/9/17/25/33/41/49/57;
    
    *@param* `y` - 列号(单位:像素点): 1-128;
    
    *@param* `size` - 字号: big(大16*16)/small(小8*8);
    
    *@param* `mode` - 显示模式: forward(黑字白底)/reverse(白字黑底); 
    
    *@param* `num` - 数字 

    e.g.

    OLED().displayNum(1, 1, "big", "forward", 123.4) 
    """
    pass

