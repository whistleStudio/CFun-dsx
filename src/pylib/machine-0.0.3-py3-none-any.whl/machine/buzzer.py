class Buzzer:
  """ 板载蜂鸣器 """
  def __init__(self) -> None:
    """ 板载蜂鸣器实例 """
    pass

  def tone (self, pitch: str) -> None:
    """ 
    发出指定音调

    *@param* `pitch` - 音高: "E7"/"F7"/"G7"/"A7"/"B7"/"C8"/"D8"

    e.g.

    Buzzer().tone("E7")  
    """
    pass

  def close (self) -> None:
    """  
    关闭
    """
    pass
  