from machine._customtype import IoPort, uint8, bit

class Servo:
  """ 舵机模块 """
  def __init__(self, port: IoPort) -> None:
    """ 
    舵机实例 
    
    *@param* `port` - 接口编号: 1、2、5、8、11、12、13、14、15、19、20
    """
    pass

  def angle(self, ang: uint8, kind: bit) -> None:
    """ 
    舵机快速旋转至指定角度; 旋转过程会造成程序阻塞

    *@param* `ang` - 角度(°);

    *@param* `kind` - 规格(硬件自身属性决定): 0(0-180°)/1(0-270°) 

    e.g.

    Servo(1).angle(185, 1)
    """
    pass

  def slowangle(self, ang: uint8, kind: bit) -> None:
    """
    舵机平缓转至指定角度; 旋转过程会造成程序阻塞, 刚上电时默认角度置零

    *@param* `ang` - 角度(°);

    *@param* `kind` - 规格(硬件自身属性决定): 0(0-180°)/1(0-270°)

    e.g.

    Servo(1).slowangle(185, 1)    
    """
    pass