from machine._customtype import IoPort

class Weigh:
  """ 称重传感器 """

  def __init__(self, sck: IoPort, dt: IoPort) -> None:
    """  
    称重实例

    *@param* `sck` - 时钟线接口: 1、2、5、8、11、12、13、14、15、19、20;

    *@param* `dt` - 数据线接口: 1、2、5、8、11、12、13、14、15、19、20

    """
    pass

  def read (self, a: float, b: float) -> float:
    """ 
    读取重量; 称重结果呈线性变化: `y = a + bx`; 测量时, 应先确定a,b数值大小; 
    
    测量方法参照: <a href="https://dict.cfunworld.com/tutorial/cfdsx/06_weigher/编程实现.html">https://dict.cfunworld.com/tutorial/cfdsx/06_weigher/编程实现.html</a>

    *@param* `a` - 零漂, 空载时的偏移值;

    *@param* `b` - 修正系数

    *@returns* - 重量(克g)

    e.g.

    Weigh(1, 2).read(-15.5, 0.98)
    """
    return 0.0
  

