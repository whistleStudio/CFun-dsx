from machine._customtype import uint8, IoPort

class Moisture:
  """ 土壤湿度传感器 """
  def __init__(self, port: IoPort) -> None:
    """
    土壤湿度实例

    *@param* `port` - 接口编号: 1、2、5、8、11、12、13、14、15、19、20
    """
    pass

  def read (self) -> uint8:
    """ 
    读取土壤湿度值

    *@returns* - 单位% 
    
    e.g.

    Moisture(1).read()
    """
    return 0
  
