from machine._customtype import bit, uint8

class ASR:
  """ 板载语音识别 """

  def __init__(self) -> None:
    """ 板载语音识别实例 """
    pass

  def ledFlag(self, mode: bit) -> None:
    """ 
    设置语音识别指示灯(板载P15灯); 开启时, 检测到可识别语音指令时, 亮灯 
    
    *@param* `mode` - 指示灯模式: 0(关闭)/1(开启)

    e.g.

    ASR().ledFlag(1) 
    """
    pass


  def read(self) -> uint8:
    """ 
    读取识别到的语音指令编号

    *@returns* - 语音指令对应编号
    
    参考文档: <a href='https://docs.qq.com/sheet/DUnF2d0JNSkpHT3FQ?tab=000001' target='_blank'>https://docs.qq.com/sheet/DUnF2d0JNSkpHT3FQ?tab=000001</a>
    """
    return 0

