from typing import Any, Literal, Annotated
from dataclasses import dataclass

@dataclass
class ValueRange:
  min: int
  max: int



bit = Annotated[int, ValueRange(0, 1)]
uint8 = Annotated[int, ValueRange(0, 255)]
uint16 = Annotated[int, ValueRange(0, 65535)]
short = Annotated[int, ValueRange(-32768, 32767)]
char = Annotated[int, ValueRange(-128, 127)]
IoPort = Annotated[int, "取值范围[1, 2, 5, 8, 11, 12, 13, 14, 15, 19, 20]"]
ADCPort = Annotated[int, "取值范围[1, 2, 13, 14, 20]"]

# 数字输入/输出模式
IoPortMode = Literal["in", "out"]

# 分别对应P1-P6
IICPort = Literal["A0", "A2", "A4", "A6", "B0", "C0"]

# 分别对应P7-P8
UARTPort = Literal[1, 2]


# 颜色id
ColorId = Literal[1, 2, 3, 4, 5, 6, 7, 8]